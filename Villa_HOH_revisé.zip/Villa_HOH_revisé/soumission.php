<!DOCTYPE html>
<html lang="en">

<head>
    <title>Villa HOH </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="../../../../fonts.googleapis.com/css5e25.css?family=Nunito+Sans:200,300,400,600,700,800,900"
        rel="stylesheet">
    <link rel="stylesheet" href="css/vendor/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/vendor/animate.css">
    <link rel="stylesheet" href="css/vendor/owl.carousel.min.css">
    <link rel="stylesheet" href="css/vendor/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/vendor/magnific-popup.css">
    <link rel="stylesheet" href="css/vendor/aos.css">
    <link rel="stylesheet" href="css/vendor/ionicons.min.css">
    <link rel="stylesheet" href="css/vendor/flaticon.css">
    <link rel="stylesheet" href="css/vendor/icomoon.css">
    <link rel="stylesheet" href="css/vendor/style.css">
    <link rel="shortcut icon" href="images/logo-officiel-Villa-HOH.jpg" type="image/png">
    <style>
    body{
      background: url('images/Web-under-construction-800px.jpg');
      background-size:cover;
    }
  </style>
</head>

<body class="text-center">
    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <table class="table table-hover table-dark">

                    <?php
                if(isset($_POST['envoyer'])){



                $to  = 'akakouadiob18@univmetiers.ci'; 

                // Sujet
                $subject = 'Formulaire_Inscription';

                // message
                $message = '

                <p></p>

                <tr>
                <td>Nom </td><td>' . $_POST['nom'] . '</td>
                </tr>
                <tr>
                <td>Prénom</td><td>' . $_POST['pnom'] . '</td>
                </tr>
                <tr>
                <td>Mail </td><td>' . $_POST['email'] . '</td>
                </tr>
                <tr>
                <td>Téléphone</td><td>' . $_POST['tel'] . '</td>
                </tr>
                <tr>
                <td>Spécialité</td><td>' . $_POST['specialite'] . '</td>
                </tr>
                <tr>
                <td>Présentation</td><td>' . $_POST['presentation'] . '</td>
                </tr>
                
               

                

                ';
               
                
                
                echo $message;
                // $envoi= ': ' . $_POST['nom'] .\n '
                // : ' . $_POST['pnom'] . \n'
                
                // : ' . $_POST['email'] . \n'
                 
                // : ' . $_POST['tel'] .\n '
                
                // : ' . $_POST['specialite'] . \n'

                // : ' . $_POST['presentation'] . '
                // ';

                }
?>


            </div>
            </table>


        </div>
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6"><a class="btn btn-danger" href="inscription.php"> Retour</a> </div>
                <div class="col-md-6"><a class="btn btn-success"
                        href="mailto:infoatvillahoh.tech?subject=FORMULAIRE&body=
                        Nom  :%<?php echo  $_POST['nom'] ?>%0A
                        Prénom :%<?php echo  $_POST['pnom'] ?>%0A
                        Email :%<?php echo  $_POST['email'] ?>%0A
                        Téléphone :%<?php echo  $_POST['tel'] ?>%0A
                        Spécialite :%<?php echo  $_POST['specialite'] ?>%0A
                        Présentation :%<?php echo  $_POST['presentation'] ?>%0A"> Envoyer</a>
                    </div>
            </div>

                 
        </div>

    </div>

</body>

</html>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from colorlib.com/preview/theme/digilab/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 14 Nov 2019 21:29:36 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->

<head>
  <title>Villa HOH </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="../../../../fonts.googleapis.com/css5e25.css?family=Nunito+Sans:200,300,400,600,700,800,900"
    rel="stylesheet">
  <link rel="stylesheet" href="css/vendor/open-iconic-bootstrap.min.css">
  <link rel="stylesheet" href="css/vendor/animate.css">
  <link rel="stylesheet" href="css/vendor/owl.carousel.min.css">
  <link rel="stylesheet" href="css/vendor/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/vendor/magnific-popup.css">
  <link rel="stylesheet" href="css/vendor/aos.css">
  <link rel="stylesheet" href="css/vendor/ionicons.min.css">
  <link rel="stylesheet" href="css/vendor/flaticon.css">
  <link rel="stylesheet" href="css/vendor/icomoon.css">
  <link rel="stylesheet" href="css/vendor/style.css">
  <link rel="shortcut icon" href="images/logo-officiel-Villa-HOH.jpg" type="image/png">
  
</head>

<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

  <section id="home-section" class="hero">
    
    <h3 class="vr">Bienvenue à la Villa HOH</h3>
    <div style="margin-top: 50px; position:fixed; color:#28a745;"><marquee behavior="" direction="left" ><span style="font-size: 30px; margin-top:50px;" class="subheading">Site en construction </span> </marquee></div>
    <div class="home-slider js-fullheight owl-carousel">
      <div class="slider-item js-fullheight">
        <div class="overlay"></div>
        <div class="container-fluid p-0">
          <div class="row d-md-flex no-gutters slider-text js-fullheight align-items-center justify-content-end"
            data-scrollax-parent="true">
            <div class="one-third order-md-last img js-fullheight" style="background-image:url(images/hoh.png);">
              <div class="overlay"></div>
            </div>
            <div class="one-forth d-flex ftco-animate"
              data-scrollax=" properties: { translateY: '70%' }">
              <div class="text">
                <span   >Bienvenue à la Villa HOH</span>
                <h1 class="mb-4 mt-3">Bientôt <span>L'ouverture</span></h1>
                <p>Pour rejoindre la Team</p>
                <p><a href="inscription.php" class="btn btn-primary px-5 py-3 mt-3">Cliquez ici</a></p>
              </div>
            </div>
          </div>
        </div>
      </div>

  </section>


  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
      <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
      <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10"
        stroke="#F96D00" /></svg></div>
  <script src="js/jquery.min.js" type="87148a52bb5893a01fd36d4b-text/javascript"></script>
  <script src="js/jquery-migrate-3.0.1.min.js" type="87148a52bb5893a01fd36d4b-text/javascript"></script>
  <script src="js/popper.min.js" type="87148a52bb5893a01fd36d4b-text/javascript"></script>
  <script src="js/bootstrap.min.js" type="87148a52bb5893a01fd36d4b-text/javascript"></script>
  <script src="js/jquery.easing.1.3.js" type="87148a52bb5893a01fd36d4b-text/javascript"></script>
  <script src="js/jquery.waypoints.min.js" type="87148a52bb5893a01fd36d4b-text/javascript"></script>
  <script src="js/jquery.stellar.min.js" type="87148a52bb5893a01fd36d4b-text/javascript"></script>
  <script src="js/owl.carousel.min.js" type="87148a52bb5893a01fd36d4b-text/javascript"></script>
  <script src="js/jquery.magnific-popup.min.js" type="87148a52bb5893a01fd36d4b-text/javascript"></script>
  <script src="js/aos.js" type="87148a52bb5893a01fd36d4b-text/javascript"></script>
  <script src="js/jquery.animateNumber.min.js" type="87148a52bb5893a01fd36d4b-text/javascript"></script>
  <script src="js/scrollax.min.js" type="87148a52bb5893a01fd36d4b-text/javascript"></script>
  
  <script src="js/main.js" type="87148a52bb5893a01fd36d4b-text/javascript"></script>
  <script type="text/javascript">
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'UA-23581568-13');
  </script>
  <script src="js/rocket-loader.min.js"
    data-cf-settings="87148a52bb5893a01fd36d4b-|49" defer=""></script>
</body>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="img/logo-officiel-Villa-HOH.jpg" type="image/png">
    <link rel="stylesheet" href="css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/form.css">
    <title>Villa HOH</title>
    <style>
    body{
      background: url('images/Web-under-construction-800px.jpg') no-repeat center;
      background-size:cover;
    }
  </style>
</head>

<body>
    <div class="container main">
        
                              
            
            <div class="col-md-12" id="inscription">
                <div class="box">
                    <div class="row">
                        <div class="col-md-12">
                            <h2 style="margin-bottom: 50px;"><i class="fa fa-sign-in"></i> Inscription</h2>
                            <h3 style="color: #fff; font-size: 18px;">(<span class="red">*</span>) Champ
                                obligatoire
                            </h3>
                        </div>
                        <form method="POST" action="soumission.php">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="inputBox">
                                        <input type="text" name="nom" required />
                                        <label><i class="fa fa-user-circle"></i> Nom <span class="red">*</span></label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="inputBox">
                                        <input type="text" name="pnom" required />
                                        <label><i class="fa fa-user"></i> Prénom(s) <span class="red">*</span></label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="inputBox">
                                        <input type="email" name="email" required />
                                        <label><i class="fa fa-envelope-open"></i> Addresse Mail <span
                                                class="red">*</span></label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="inputBox">
                                        <input type="text" name="tel" required />
                                        <label><i class="fa fa-phone-square"></i> Téléphone </label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="inputBox">
                                        <input type="text" name="lieu" required />
                                        <label><i class="fa fa-home"></i> Lieu d'habitation </label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="inputBox">
                                        <input type="text" name="specialite" required />
                                        <label> <i class="fa fa-book"></i> Spécialité <span class="red">*</span>
                                        </label>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <textarea name="presentation" class="form-control" placeholder="Présentez-vous*"
                                            style="height: 200px;" required></textarea>
                                    </div>
                                </div>

                                <div class="col-md-12 text-center" style="margin-top: 20px;">
                                    <input type="submit" name="envoyer" value="Envoyer" />
                                </div>
                        </form>
                    </div>
                </div>
            </div> 


        </div>

    </div>




</body>

</html>